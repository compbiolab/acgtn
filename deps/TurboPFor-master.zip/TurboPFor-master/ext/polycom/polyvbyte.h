#ifdef __cplusplus
extern "C" {
#endif
unsigned char *vbpolyenc(unsigned      *in, unsigned n, unsigned char *out);
unsigned char *vbpolydec(unsigned char *in, unsigned n, unsigned *out);
#ifdef __cplusplus
}
#endif


