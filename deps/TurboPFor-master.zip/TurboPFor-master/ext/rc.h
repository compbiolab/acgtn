#ifdef __cplusplus
extern "C" {
#endif
unsigned char *rcenc32(unsigned* input, int size, unsigned* output);
unsigned char *rcdec32(unsigned* input, int size, unsigned* output);
#ifdef __cplusplus
}
#endif
